# om-wallpapers-extra-twm
Collection of wallpapers provided by OpenMandriva users for Tiling Window Manager
